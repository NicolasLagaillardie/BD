/********************* CREATION DES TABLES ******************
*************************************************************/

drop table position cascade constraints;

create table position 
(ref varchar2(100), pos varchar2(80));


drop table calibration cascade constraints;

CREATE TABLE calibration (
  ref varchar(100)  DEFAULT '' NOT NULL,
  name varchar(100) NOT NULL,
  internal_value number(6,2) NOT NULL,
  external_value number(6,2) NOT NULL,
  date_c date NOT NULL
);

drop table events cascade constraints;
CREATE TABLE events (
  id integer NOT NULL,
  ref varchar2(100) NOT NULL,
  ts date DEFAULT NULL,
  server_ts date NOT NULL,
  name_p varchar(100) NOT NULL,
  value number(6,2) DEFAULT NULL,
  firm_vers varchar2(6) DEFAULT NULL,
  PRIMARY KEY (id)
);


/********************* CREATION DES SYNONYMES ********************************/
/*****************************************************************************/

/**   (par l'user SYS) **/
drop SYNONYM POSITION;
drop  SYNONYM CALIBRATION ;
drop SYNONYM CEVENTS ;

CREATE PUBLIC SYNONYM POSITION FOR c##capteurs.POSITION;
CREATE PUBLIC SYNONYM CALIBRATION FOR c##capteurs.POSITION;
CREATE PUBLIC SYNONYM CEVENTS FOR c##capteurs.EVENTS; /* attention, le nom du synonyme varie un peu car la table EVENTS existe avec un synonyme public */ 




/* (par l'user c##capteurs) */
GRANT SELECT ON c##capteurs.POSITION TO PUBLIC;
GRANT SELECT ON c##capteurs.POSITION TO PUBLIC;
GRANT SELECT ON c##capteurs.EVENTS TO PUBLIC

GRANT INDEX ON c##capteurs.POSITION TO PUBLIC;
GRANT INDEX ON c##capteurs.POSITION TO PUBLIC;
GRANT INDEX ON c##capteurs.EVENTS TO PUBLIC;

GRANT REFERENCES ON c##capteurs.POSITION TO PUBLIC;
GRANT REFERENCES ON c##capteurs.POSITION TO PUBLIC;
GRANT REFERENCES ON c##capteurs.EVENTS TO PUBLIC;

